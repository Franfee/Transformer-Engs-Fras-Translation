# -*- coding: utf-8 -*-
# @Time    : 2022/11/23 15:40
# @Author  : FanAnfei
# @Software: PyCharm
# @python  : Python 3.9.12

class Accumulator:
    """For accumulating sums over `n` variables."""
    def __init__(self, n):
        """Defined in :numref:`sec_softmax_scratch`"""
        self.data = [0.0] * n

    def __getitem__(self, idx):
        return self.data[idx]

    def add(self, *args):
        self.data = [a + float(b) for a, b in zip(self.data, args)]

    def reset(self):
        self.data = [0.0] * len(self.data)
